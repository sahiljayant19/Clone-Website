const posters = document.querySelectorAll('.poster');
const toggleNav = document.getElementById('tgl');
const menu = document.getElementById('menu');
const nav = document.getElementById('nav');
const search = document.getElementById('search');
const state = document.getElementById('state');
const login = document.getElementById('login');
const slider = document.getElementById('slider');
const menuImg = document.getElementById('menuImg');
const show_el = [search, state, login];
const hide_el = [toggleNav, search, state, login];
let index = 0;
let count = 0;
let menuClicked = false;

function posterAnimation() {
    setInterval(() => {
        index = (index > 2) ? 0 : index;
        Array.from(posters).forEach((poster) => {
            poster.style.display = 'none';
        });
        posters[index].style.display = 'block';
        index++;
    }, 5000);
}
posterAnimation();

function showElements(element) {
    element.style.display = 'block';
}

function hideElements(element) {
    element.style.display = 'none';
}

window.addEventListener('resize', () => {
    if (window.innerWidth > 480) { // Runtime condition
        nav.style.height = '64px';
        toggleNav.style.display = 'flex';
        show_el.map(showElements);
        menuClicked = false;
    }
    else if (window.innerWidth <= 480 && menuClicked == false) { // Runtime condition
        hide_el.map(hideElements);
    }
});

menu.addEventListener('click', () => {
    menuClicked = true;
    if (toggleNav.style.display == 'flex') { // Condition for hide elements
        menu.innerHTML = `<img src="img/menu.png" alt="" width="30px" id="menuImg">`
        nav.style.height = '64px';
        setTimeout(() => {
            hide_el.map(hideElements);
        }, 50);
    }
    else { // Condition for show elements
        menu.innerHTML = `<img src="img/close.png" alt="" width="25px" id="menuImg">`
        nav.style.transition = '0.5s';
        nav.style.height = '200px';
        setTimeout(() => {
            toggleNav.style.display = 'flex';
            show_el.map(showElements);
        }, 100);
    }
});